from Utile import *


"""
On utilisera tout au long les variables:
chiffre = valeur d'un chiffre présent dans cfr
c = position du chiffre dans la liste cfr
r = position d'un case dans un rang
"""


def CfrTakePlaceOnLeft(cfr, ranck, ranckSure, cParam): #Renvoie la case à partir de laquelle le chiffre pourra être placé
    r = 0
    for c in range(cParam):
        chiffre = cfr[c]
        if (IsInSure(ranckSure, c)): #Si c est associé
            r = LocateLastBlackCaseAssociate(ranckSure, c) + 2
        else:
            while True:
                if (IsEnouthLong(ranck, chiffre, r)):
                    r += chiffre + 1
                    break
                else:
                    r += 1
    return r

def CfrTakePlaceOnRight(cfr, ranck, ranckSure, cParam): #Renvoie la case à jusqu'à laquelle le chiffre pourra être placé
    r = last(ranck)
    for c in range(last(cfr), cParam, -1):
        chiffre = cfr[c]
        if (IsInSure(ranckSure, c)):    #Si c est associé
            r = LocateFirstBlackCaseAssociate(ranckSure, c) - 2
        else:
            while True:
                if (IsEnouthLong(ranck, chiffre, r - chiffre + 1)):
                    r -= chiffre + 1
                    break
                else:
                    r -= 1
    return r

def PlaceCfrSure(cfr, ranck, ranckSure, long): #placer les chiffres quand ils sont sûr*
    ranckWIthCfr = PlaceAllCfrPossibilities(cfr, ranck, ranckSure, long)
    for c in range(len(cfr)):
        chiffre = cfr[c]
        ranckWIthCfrTest = InstantiateRanckWithCfr(long)
        rMin = LocateFirstCfrInRanckWithCfr(ranckWIthCfr, c)
        rMax = LocateLastCfrInRanckWithCfr(ranckWIthCfr, c)
        while (IsEnouthLong(ranck, chiffre, rMin) == False):
            rMin += 1
        for r in range(rMin, rMin + chiffre):
            ranckWIthCfrTest[r].append(c)
        while (IsEnouthLong(ranck, chiffre, rMax - chiffre + 1) == False):
            rMax -= 1
        for r in range(rMax, rMax - chiffre, -1):
            ranckWIthCfrTest[r].append(c)
        for r in range(long):
            if (HasCorrectSize(ranckWIthCfrTest[r], 2)):
                ColorCase(ranck, r)
                ranckSure[r] = c


def PlaceAllCfrPossibilities(cfr, ranck, ranckSure, long): #Placer tous les chiffres
    ranckWithCfr = InstantiateRanckWithCfr(long)
    for c in range(len(cfr)):
        chiffre = cfr[c]
        if (IsInSure(ranckSure, c)):    #Si le chiffre est déjà associé
            bMin = LocateFirstBlackCaseAssociate(ranckSure, c)  #case noire tout à gauche de la série
            bMax = LocateLastBlackCaseAssociate(ranckSure, c)   #Case noire tout à droite de la série
            rMin01 = bMax - chiffre + 1
            rMax01 = bMin + chiffre - 1
            rMin02 = CfrTakePlaceOnLeft(cfr, ranck, ranckSure, c)
            rMax02 = CfrTakePlaceOnRight(cfr, ranck, ranckSure, c)
            if (rMin01 > rMin02):
                rMin = rMin01
            else:
                rMin = rMin02
            if (rMax01 < rMax02):
                rMax = rMax01
            else:
                rMax = rMax02
            if (rMin < 0):
                rMin = 0
            if (rMax > last(ranck)):
                rMax = last(ranck)
            while (rMin < bMin):    #remblir de c les casses à gauche de la série
                condition1 = True   #Si la case à gauche de rMin est valide
                condition2 = True   #Si les cases enrte rMin et bMin sont valides
                if (rMin > 0 and (ranck[rMin - 1]) == 2):
                    condition1 = False
                for r in range(rMin, bMin):
                    if (ranck[r] == 1):
                        condition2 = False
                if (condition1 and condition2):
                    for r in range(rMin, bMin):
                        ranckWithCfr[r].append(c)
                    break
                else:
                    rMin += 1
            while (rMax > bMax):    #Remplir de c les cases à droite de la série
                condition1 = True   #Si la case à droite de rMax est valide
                condition2 = True    #Si les cases entre bMax et rMax sont valides
                if (rMax < last(ranck)):
                    if (ranck[rMax + 1] == 2):
                        condition1 = False
                for r in range(rMax, bMax, -1):
                    if (ranck[r] == 1):
                        condition2 = False
                if (condition1 and condition2):
                    for r in range(rMax, bMax, -1):
                        ranckWithCfr[r].append(c)
                    break
                else:
                    rMax -= 1
            for r in range(bMin, bMax + 1):
                ranckWithCfr[r].append(c)
        else:   #Si le chiffre n'est pas associé
            rMin = CfrTakePlaceOnLeft(cfr, ranck, ranckSure, c)
            rMax = CfrTakePlaceOnRight(cfr, ranck, ranckSure, c) - chiffre + 1
            for r in range(rMin, rMax + 1):
                if (IsEnouthLong(ranck, chiffre, r)):   #S'il y a la place
                    for i in range(r, r + chiffre):
                        if (DoNotContains(ranckWithCfr[i], c)): #Ajouter c à toutes les cases ne le contenant pas déjà
                            ranckWithCfr[i].append(c)
    return ranckWithCfr


def WhenSeriesNotAssigned(cfr, ranck, ranckSure, long):  #Associer si possible les séries non associés
    serieAsso = NumberAssociateToSeries(ranck, PlaceAllCfrPossibilities(cfr, ranck, ranckSure, long))
    serieL = []
    for sA in serieAsso:
        if (HasCorrectSize(sA, 0)):
            return None
        c = sA[0]
        serieL.append([c])
        serieAsso = DeleteNumberForEverySeries(serieAsso, c)
    serieAsso = NumberAssociateToSeries(ranck, PlaceAllCfrPossibilities(cfr, ranck, ranckSure, long))
    serieR = []
    for sA in range(len(serieAsso) - 1, -1, -1):
        c = serieAsso[sA][last(serieAsso[sA])]
        serieR.insert(0, [c])
        serieAsso = DeleteNumberForEverySeries(serieAsso, c)

    for s in range(len(serieL)):
        if (serieL[s] == serieR[s]):
            for r in Serie(ranck)[s]:
                ranckSure[r] = serieL[s][0]


def ColorSkimpySeries(cfr, ranck, ranckSure, long):    #Colorer les bornes des séries étriquées
    ranckWithCfr = PlaceAllCfrPossibilities(cfr, ranck, ranckSure, long)
    for c in range(len(cfr)):
        chiffre = cfr[c]
        if (IsInSure(ranckSure, c)):
            bMin = LocateFirstBlackCaseAssociate(ranckSure, c)
            bMax = LocateLastBlackCaseAssociate(ranckSure, c)
            rMin = LocateFirstCfrInRanckWithCfr(ranckWithCfr, c)
            rMax = LocateLastCfrInRanckWithCfr(ranckWithCfr, c)
            if (rMax - bMin + 1 < chiffre): #Si la série est étriquée à droite colorer la gauche
                for r in range(rMax - chiffre + 1, bMin):
                    ColorCase(ranck, r)
            if (bMax - rMin + 1 < chiffre):
                for r in range(rMin + chiffre - 1, bMax, -1):
                    ColorCase(ranck, r)


def JoinSeries(cfr, ranck, ranckSure, long):  #Quand des cases noire converties ne sont pas assignées
    ranckWithCfr = PlaceAllCfrPossibilities(cfr, ranck, ranckSure, long)
    for r in range(long):
        if (ranck[r] == 2 and HasCorrectSize(ranckWithCfr[r], 1)):
            ranckSure[r] = ranckWithCfr[r][0]
    for c in range(len(cfr)):
        if (IsInSure(ranckSure, c)):
            bMin = LocateFirstBlackCaseAssociate(ranckSure, c)
            bMax = LocateLastBlackCaseAssociate(ranckSure, c)
            for r in range(bMin, bMax):
                ranckSure[r] = c
                ColorCase(ranck, r)


def AssignWhenIsAgainst(ranck, ranckSure, long):   #Assigner les cases noires voisines de séries associées
    c = None
    for i in range(long):
        r = ranck[i]
        if (r != 2):
            c = None
        elif (r == 2 and c != None):
            ranckSure[i] = c
        elif (r == 2):
            c = ranckSure[i]
    for i in range(long - 1 -1, -1):
        r = ranck[i]
        if (r != 2):
            c = None
        elif (r == 2 and c != None):
            ranckSure[i] = c
        elif (r == 2):
            c = ranckSure[i]


def CocheAroundSerie(cfr, ranck, ranckSure, long):  #Coche les cases à côté des séries completes
    serie = Serie(ranck)
    serieAsso = NumberAssociateToSeries(ranck, PlaceAllCfrPossibilities(cfr, ranck, ranckSure, long))
    for s in range(len(serie)):
        condition = True #Si tous les chiffres associés à la série ont la même valeure
        if (len(serieAsso[s]) > 1): #Si tous les chiffres associés à la série ont la même valeur
            for c in range(len(serieAsso[s]) - 1):
                if (cfr[serieAsso[s][c]] != cfr[serieAsso[s][c + 1]]):
                    condition = False
                    break
        if (condition and len(serie[s]) == cfr[serieAsso[s][0]]):
            if (serie[s][0] > 0):
                CocheCase(ranck, serie[s][0] - 1)
            if (serie[s][last(serie[s])] < last(ranck)):
                CocheCase(ranck, serie[s][last(serie[s])] + 1)


def CocheWhenNoPossibilitie(cfr, ranck, ranckSure, long):
    ranckWithCfr = PlaceAllCfrPossibilities(cfr, ranck, ranckSure, long)
    for r in range(long):
        if (len(ranckWithCfr[r]) == 0 and ranck[r] != 2):
            CocheCase(ranck, r)


def ResolveRanck(cfr, ranck, long):
    ranckSure = InstantiateRanckSure(long)
    JoinSeries(cfr, ranck, ranckSure, long)
    WhenSeriesNotAssigned(cfr, ranck, ranckSure, long)
    AssignWhenIsAgainst(ranck, ranckSure, long)
    PlaceCfrSure(cfr, ranck, ranckSure, long)
    ColorSkimpySeries(cfr, ranck, ranckSure, long)
    CocheAroundSerie(cfr, ranck, ranckSure, long)
    CocheWhenNoPossibilitie(cfr, ranck, ranckSure, long)