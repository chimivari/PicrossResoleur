
def InstantiateRanck(long):     #Instantie ranck et ranckSure avec la bonne longueure
    ranck = []
    for i in range(long):
        ranck.append(0)
    return ranck

def InstantiateRanckSure(long):
    ranckSure = []
    for i in range(long):
        ranckSure.append(None)
    return ranckSure

def InstantiateRanckWithCfr(long):  #Instantie ranckWithCfr qui est un rang test
    ranckWithCfr = []
    for i in range(long):
        ranckWithCfr.append([])
    return ranckWithCfr

def IsInSure(ranckSure, c):  #Si le chiffre de position c est associé
    if (c in ranckSure):
        return True
    else:
        return False

def last(list):     #Renvoie la position maximale qu'une liste peut avoir
    return len(list) - 1

def ColorCase(ranck, r):   #Color une case
    ranck[r] = 2

def CocheCase(ranck, r):   #Coche une case
    ranck[r] = 1

def LocateFirstBlackCaseAssociate(ranckSure, c):   #Renvoie la position de la première case noire d'une série associée
    for r in range(len(ranckSure)):
        if (ranckSure[r] == c):
            return r

def LocateLastBlackCaseAssociate(ranckSure, c):   #Renvoie la position de la derinière case noire d'une série associée
    for r in range(len(ranckSure)):
        if (c == ranckSure[r]):
            posi = r
    return posi

def LocateFirstCfrInRanckWithCfr(ranckWithCfr, c):
    for r in range(len(ranckWithCfr)):
        if (c in ranckWithCfr[r]):
            return r

def LocateLastCfrInRanckWithCfr(ranckWithCfr, c):
    for r in range(len(ranckWithCfr)):
        if (c in ranckWithCfr[r]):
            posi = r
    return posi

def IsEnouthLong(ranck, chiffre, rParam):   #Renvoie si un chiffre peut être posé
    condition1 = True  #pas de case noire à gauche
    condition2 = True  #pas de case cochée à milieu
    condition3 = True  #pas de case noire à droite
    if (rParam > 0 and ranck[rParam - 1] == 2):
        condition1 = False
    for r in range(rParam, rParam + chiffre):
        if (ranck[r] == 1):
            condition2 = False
    if ((rParam + chiffre - 1) < last(ranck)):
        if (ranck[rParam + chiffre] == 2):
            condition3 = False
    if (condition1 and condition2 and condition3):
        return True
    else:
        return False

def HasCorrectSize(list, size):
    if (len(list) == size):
        return True
    else:
        return False

def DoNotContains(list, number):
    if (number in list):
        return False
    else:
        return True

def Serie(ranck):
    serie = []
    r = 0
    p = []
    while (r < len(ranck)):
        case = ranck[r]
        if (case == 2):
            p.append(r)
        else:
            if (p != []):
                serie.append(p)
            p = []
        r += 1
    if (p != []):
        serie.append(p)
    return serie

def NumberAssociateToSeries(ranck, ranckWithCfr):
    serie = Serie(ranck)
    serieAsso = []
    for s in range(len(serie)):
        serieAsso.append([])
        for i in ranckWithCfr[serie[s][0]]:
            serieAsso[s].append(i)
    return serieAsso

def DeleteNumberForEverySeries(serie, c):
    for s in range(len(serie)):
        if (c in serie[s]):
            serie[s].remove(c)
    return serie

def IsNumber(char):
    if (char == '0' or
    char == '1' or
    char == '2' or
    char == '3' or
    char == '4' or
    char == '5' or
    char == '6' or
    char == '7' or
    char == '8' or
    char == '9'):
        return True
    else:
        return False


def IsComma(char):
    if (char == ","):
        return True
    else:
        return False


def IsNotComplete(ranckList):
    for ranck in ranckList:
        for r in ranck:
            if (r == 0):
                return True
    return False

def IsRanckNotComplete(ranck):
    for r in ranck:
        if (r == 0):
            return True
    return False