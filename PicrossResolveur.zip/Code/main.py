from Utile import *
from Resolution import *


nbCol = 0
nbLig = 0
cfrColList = [[]]
cfrLigList = [[]]
ranckColList = []
ranckLigList = []


def ConvertInCfr():
    cfrCol = input("Chiffres des colonnes = ")
    cfrLig = input("Chiffres des lignes = ")
    col = 0
    chiffre = ""
    for c in range(len(cfrCol)):
        char = cfrCol[c]
        if (c < last(cfrCol)):
            if (IsNumber(char)):
                chiffre += char
            elif (chiffre != ""):
                cfrColList[col].append(int(chiffre))
                chiffre = ""
                if (IsComma(char)):
                    cfrColList.append([])
                    col += 1
        else:
            if (IsNumber(char)):
                chiffre += char
                cfrColList[col].append(int(chiffre))
    ver = 0
    chiffre = ""
    for c in range(len(cfrLig)):
        char = cfrLig[c]
        if (c < last(cfrLig)):
            if (IsNumber(char)):
                chiffre += char
            elif(chiffre != ""):
                cfrLigList[ver].append(int(chiffre))
                chiffre = ""
                if (IsComma(char)):
                    cfrLigList.append([])
                    ver += 1
        else:
            if (IsNumber(char)):
                chiffre += char
                cfrLigList[ver].append(int(chiffre))
    global nbLig
    global nbCol
    nbLig = len(cfrLigList)
    nbCol = len(cfrColList)

def InstantiateGrid():
    for i in range(nbCol):
        ranckColList.append(InstantiateRanck(nbLig))
    for i in range(nbLig):
        ranckLigList.append(InstantiateRanck(nbCol))


def ConvertTo(col, lig):
    for ranck in range(len(col)):
        for case in range(len(col[ranck])):
            lig[case][ranck] = col[ranck][case]

def ShowExemple():
    print("Exemple de grille possible : ")
    print("    2   1   1")
    print("    1 4 1 4 2")
    print("1 2")
    print("  4")
    print("1 1")
    print("  4")
    print("2 1")
    print("Rentrez les coordonnées comme ceci")
    print("Chiffres des colonnes = 2 1,4,1 1,4,1 2")
    print("Chiffres des lignes = 1 2,4,1 1,4,2 1")
    print()
    print("A votre tour d'essayer")

def Display():
    for ranck in ranckLigList:
        rang = ""
        for r in ranck:
            if (r == 1):
                rang += "." #Case noire
            else:
                rang += "X" #Case cochée
            rang += " "
        print(rang)
    print("Légende :    X = Case Noire")
    print("             . = Case Cochée")

def Resolve():
    ShowExemple()
    ConvertInCfr()
    InstantiateGrid()
    while (IsNotComplete(ranckColList)):
        for col in range(len(ranckColList)):
            if (IsRanckNotComplete(ranckColList[col])):
                ResolveRanck(cfrColList[col], ranckColList[col], nbLig)
        ConvertTo(ranckColList, ranckLigList)
        for lig in range(len(ranckLigList)):
            if (IsRanckNotComplete(ranckLigList[lig])):
                ResolveRanck(cfrLigList[lig], ranckLigList[lig], nbCol)
        ConvertTo(ranckLigList, ranckColList)
    Display()

"""
Quelques exemples :

Chiffres des colonnes = 6,7,8,9,5 3,5 3,9,8,7,6
Chiffres des lignes = 2,4,6,8,10,4 4,4 4,10,10,10

Chiffres des colonnes = 2 5 1,11 1,7 3 1,3 5 2 1,4 1 2 3 1,4 3 2 1,5 3 2 2,5 3 2 2,3 7,2 4,3 8,2 8 7,1 8 3 2,4 3 3 2,5 3 1,6 5 1,3 5 1,3 8 1,10 1,4 1
Chiffres des lignes = 4 4,11 5,11 7,3 5 8,3 2 3 2 2,4 1 4 2 3,4 5 1 3,7 5 3,2 5 5 4,3 3 3 4,5 1 2 5,5 1 7,4 6,3 3,1 1,1 1,1 1,1 1,3 3,9 9

Chiffres des colonnes = 1,15 1,3 4 5,2 2 4 2 4,2 1 1 3 2 4,2 1 4 2 1,2 9 1,2 1 1 1 2 1,2 3 1 2 1,2 1 1 1 1 1,2 1 1 1 1 1,2 3 1 2 1,2 3 1 1 2 1,2 3 8 1,2 1 1 4 2 1,2 1 3 3 2 4,2 1 5 2 4,3 4 5,15 1,1
Chiffres des lignes = 16,18,2 2,1 2 1 1,1 1 1 1,1 3 1,1 1 1 1,1 2 5 1,1 1 1 1 1 1,18,6 1 1 6,18,2 2 2 2,1 2 8 2 1,1 2 1 1 2 1,2 10 2,7 7,3 3,3 3,20

Chiffres des colonnes =  3,8 4,10 1 4,9 1 6,3 1 7,21 7,22 7,22 7,22 7,21 7,3 1 7,7 1 6,8 1 4,6 4,3
Chiffres des lignes = 3,5,5,5 1,5 3,5 3,5 3,1 5 3,3 9,3 9,3 8,3 5,3 5,3 5,9,9,8,5,5,5,5,15,2 2,15,13,11,11,9,9,7

Chiffres des colonnes = 1,3,5,7,4 4,3 3,3 3,3 3,3 2,2 5 2,2 2 1 3,2 2 3 1 2,4 1 3 4,3 1 4 3,3 3 3 3,3 7 3,4 5 4,2 2 3 1 2,3 2 1 3,2 5 2,3 2,3 3,3 3,3 3,4 4,7,5,3,1,1
Chiffres des lignes = 9,15,4 5 5,5 2 2 5,4 2 3 2 4,4 2 1 3 2 4,4 1 1 4 1 4,4 1 3 3 1 5,4 1 7 1 4,4 1 5 1 4,4 1 3 1 4,4 2 2 4,5 5 5,15,9

Chiffres des colonnes = 3,2 3,3 2 2 2,5 1 2 1 3,5 1 2 3 4,5 1 9 2,5 1 2 1 1 1  1,5 1 2 1 1 1,3 2 2 2,2 3,3
Chiffres des lignes = 5,7,7,7,1 5 1,2 2,1 7 1,2 2,11,9,1,1,3,3 1,3,1,3,2 1,4 1,7
"""

Resolve()